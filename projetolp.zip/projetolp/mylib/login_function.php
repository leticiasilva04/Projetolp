<?php

function login($email, $senha){
    ob_start();
   // session_start();
    $handle = file('../projeto/dados/contas.txt');
    foreach($handle as $linha){
        $data = json_decode($linha);
        var_dump($data);
        if($data->email === $email && $data->senha === $senha){
            $_SESSION["email"] = $email;
            $_SESSION["nome"] = $data->nome;
            $_SESSION["isLogged"] = true;
            header("Location: logado.php");
            exit;
        }
        else {
            header("Location: conta_invalida.php");
        }
    }
}



?>