<?php 

//gera a data atual no formato brasileiro
//@return string: a data atual

/*function dataBR(){
    return date('d/m/Y');
}*/

function dataBR() {
    date_default_timezone_set('America/Sao_Paulo');
    return date('d/m/Y H:i:s', time());
}

?>