<!-- Formulário de Cadastro -->
<form class="text-center border border-light p-5" method="POST" action="../projeto/dados/dados_cadastro.php">

  <p class="h4 mb-4" id="cadastro">Cadastro</p>

  <!-- Nome -->
  <input type="text" id="nome" name="nome" class="form-control mb-4" placeholder="Nome" required>

  <input type="text" id="sobrenome" name="sobrenome" class="form-control mb-4" placeholder="Sobrenome" required>

  <!-- Email -->
  <input type="email" id="email" name="email" class="form-control mb-4" placeholder="E-mail" required>

   <!-- Senha -->
  <input type="password" id="senha" name="senha" class="form-control mb-4" placeholder="Senha" required>

  <!-- Telefone -->
  <input type="text" id="telefone" name="telefone" class="form-control md-4" placeholder="Telefone" required>

  <!-- Foto-->
  <br>
  <div class="input-group">
  <div class="input-group-prepend">
    <span class="input-group-text">Foto</span>
  </div>
  <div class="custom-file">
    <input type="file" class="custom-file-input" name= "foto" id="foto"
      aria-describedby="inputGroupFileAddon01" required>
    <label class="custom-file-label" for="foto">Selecione sua foto</label>
  </div>
</div>


  <br>

  <!-- Botão de Enviar -->
  <button class="btn btn-success" type="submit">Enviar</button>

</form>
<!-- Fim - Form -->