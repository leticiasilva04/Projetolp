

<div class="card card-image" style="background-image:
url(https://images.unsplash.com/photo-1444392061186-9fc38f84f726?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2072&q=80);">
  <div class="text-white text-center rgba-stylish-strong py-5 px-4">
    <div class="py-5">

      <!-- Content -->
      <h5 class="h5 text-success"><i class="fas fa-feather-alt"></i> Viridário</h5>
      <h2 class="card-title h2 my-4 py-2">Do plantio à manutenção, deixe-nos cuidar do seu jardim!</h2>
      <p class="mb-4 pb-2 px-md-5 mx-md-5">A Viridário é uma empresa de jardinagem preparada para tornar seus espaços verdes mais bonitos, harmônicos e funcionais, oferecendo serviços de qualidade para cuidar do seu jardim e torná-lo um ambiente acolhedor e agradável para você aproveitar. 
<br> <br> <br>
Floresça com o nosso toque verde!
      </p>

    </div>
  </div>
</div>

