<!-- Footer -->
<footer class="page-footer font-small teal pt-4 bg-success">

  <div class="container-fluid text-center text-md-left">

    <div class="row">

      <div class="col-md-6 mt-md-0 mt-3">

        <!-- Conteudo -->
        <h5 class="text-uppercase font-weight-bold" id="contato">Contato</h5>
        <p>Viridário - Empresa de Jardinagem
          <br>
          R. Dr. Zuquim, 1698 - Santana, São Paulo - SP, 02035-022
          <br>
           (11) 2337-6560
           <br>
           (11) 97356-7561
          <br>
          contato@viridario.com.br
        </p>

      </div>

      <hr class="clearfix w-100 d-md-none pb-3">

    </div>

  </div>

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2023 Copyright:
    <a href="/"> Leticia Ferreira da Silva - GU3032043</a>
  </div>
  <!-- Copyright -->

</footer>
