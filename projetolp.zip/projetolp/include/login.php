



<!-- Form Login -->
<form class="text-center border border-light p-5" method="POST" action="../projeto/logado.php">

    <p class="h4 mb-4" id="login">Login</p>

    <!-- Email -->
    <input type="email" id="email" name="email" class="form-control mb-4" placeholder="E-mail">

    <!-- Senha -->
    <input type="password" id="senha" name="senha" class="form-control mb-4" placeholder="Senha">

    <div class="d-flex justify-content-around">
        <div>

        </div>
    </div>

    <!-- Botão enviar -->
    <button class="btn btn-info btn-block my-4" type="submit">Logar</button>

    <!-- Registro -->
    <p>Não possui uma conta?
        <a href="criar_cadastro.php">Cadastre-se</a>
    </p>

</form>



