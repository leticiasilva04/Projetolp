<!--Navbar-->
<nav class="navbar navbar-expand-lg navbar-dark bg-success"> <!--@Aqui que muda a cor da navbar-->

  <a class="navbar-brand" href="#">Menu</a>

  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#basicExampleNav"
    aria-controls="basicExampleNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="basicExampleNav">

    <!-- Itens -->
    <ul class="navbar-nav mr-auto">

      <li class="nav-item">
        <a class="nav-link" href="#top">Home
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="#sobre">Sobre</a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="#servicos">Serviços</a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="#login">Login</a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="#contato">Contato</a>
      </li>

    </ul>
  <!-- Itens -->

</nav>
