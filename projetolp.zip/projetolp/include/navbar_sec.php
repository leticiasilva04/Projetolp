<!--Navbar para as outras páginas -->

<nav class="navbar navbar-expand-lg navbar-dark bg-success"> 


  <a class="navbar-brand" href="#top">Menu</a>

  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#basicExampleNav"
    aria-controls="basicExampleNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="basicExampleNav">

    <!-- Itens da Navbar -->
    <ul class="navbar-nav mr-auto">

      <li class="nav-item">
        <a class="nav-link" href="index.php">Home
        </a>
      </li>

      <?php if(isset($_SESSION['isLogged'])): ?>
        <li class="nav-item">
        <a class="nav-link" href="logado.php">Caixa de Sugestões</a>
      </li>
    <?php endif;?>

      <li class="nav-item">
        <a class="nav-link" href="visualizar_sugestoes.php">Mural de Sugestões</a>
      </li>

    </ul>
  <!-- Itens da Navbar -->

</nav>
