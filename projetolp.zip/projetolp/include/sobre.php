<!-- Jumbotron 2 -->
<div class="jumbotron text-center">

  <!-- Title -->
  <h4 class="card-title h4 pb-2 green-text"><strong>A VIRIDÁRIO</strong></h4>

  <!-- Card image -->
  <div class="view overlay my-4">
    <img src="../imagens/imagem2.jpg" class="img-fluid" alt="">
    <a href="#">
      <div class="mask rgba-white-slight"></div>
    </a>
  </div>

  <h5 class="indigo-text h5 mb-4" id="sobre">A NATUREZA É A NOSSA INSPIRAÇÃO</h5>

  <p class="card-text">A nossa empresa de jardinagem e paisagismo é especializada em transformar espaços verdes em ambientes deslumbrantes e funcionais. Temos orgulho em oferecer serviços personalizados e de alta qualidade para clientes que valorizam a beleza e a natureza em seus espaços ao ar livre.
<br> <br>
    Nossa equipe de especialistas em jardinagem tem anos de experiência em design paisagístico, manutenção de jardins e instalação de sistemas de irrigação. Nosso objetivo é criar um ambiente que atenda às suas necessidades e que se adapte ao seu estilo de vida. Quer você esteja procurando por um jardim de flores coloridas, um espaço para entretenimento ao ar livre ou um ambiente relaxante para desfrutar com a família, podemos ajudá-lo a transformar sua visão em realidade.
    <br> <br>
    Oferecemos uma variedade de serviços de jardinagem, desde o planejamento e design paisagístico até a manutenção regular do jardim. Nossos especialistas podem ajudá-lo a escolher as plantas certas para o seu clima, solo e nível de exposição à luz solar. Eles também podem ajudar na instalação de sistemas de irrigação eficientes para garantir que suas plantas recebam a quantidade adequada de água e nutrição.
    <br> <br>
    Estamos comprometidos em fornecer um serviço excepcional aos nossos clientes e em garantir que cada projeto seja concluído dentro do prazo e do orçamento estabelecidos. Nosso objetivo é superar as suas expectativas e criar um jardim que você ame e se orgulhe de mostrar aos seus amigos e familiares.
    <br> <br>
    Além disso, valorizamos a sustentabilidade e a preservação do meio ambiente. Utilizamos práticas ecológicas em nossos serviços de jardinagem e buscamos sempre reduzir o desperdício e minimizar o impacto ambiental.
    <br> <br>
    Se você está procurando uma empresa de jardinagem e paisagismo confiável e experiente, entre em contato conosco hoje mesmo para agendar uma consulta. Deixe-nos ajudá-lo a transformar seu espaço ao ar livre em um ambiente deslumbrante e funcional que atenda às suas necessidades e supera suas expectativas!
<br> <br>
<h6 class="green-text h5 mb-4"> Missão: </h6>
<p class="card-text"> Proporcionar um ambiente mais saudável e agradável para as pessoas através da criação e manutenção de jardins e áreas verdes, sempre buscando a excelência em nossos serviços.</p>

<h6 class="green-text h5 mb-4"> Visão: </h6>
<p class="card-text"> Ser reconhecida como a melhor empresa de jardinagem da região, mantendo uma equipe qualificada e comprometida com a satisfação dos nossos clientes. </p>

<h6 class="green-text h5 mb-4"> Valores: </h6>

<p class="card-text"> 
<strong> Ética: </strong> agir sempre com transparência e respeito aos clientes, colaboradores e parceiros; <br>
<strong> Qualidade: </strong> buscar sempre a excelência em nossos serviços e produtos, visando a satisfação do cliente; <br>
<strong> Comprometimento: </strong>atender às necessidades dos clientes, com agilidade e qualidade; <br>
<strong> Inovação: </strong>buscar constantemente novas ideias e tecnologias para aprimorar nossos serviços e produtos; <br>
<strong> Sustentabilidade:</strong> preservar o meio ambiente e utilizar técnicas de jardinagem sustentáveis. 
</p>

  <br> <br>
  <strong>Confira as nossas redes sociais</strong>
  </p>

  <!-- Linkedin -->
  <a class="fa-lg p-2 m-2 li-ic"><i class="fab fa-linkedin-in green-text"></i></a>
  <!-- Twitter -->
  <a class="fa-lg p-2 m-2 tw-ic"><i class="fab fa-twitter green-text"></i></a>
  <!-- Facebook -->
  <a class="fa-lg p-2 m-2 fb-ic"><i class="fab fa-facebook-f green-text"></i></a>

</div>
<!-- Jumbotron 2 -->