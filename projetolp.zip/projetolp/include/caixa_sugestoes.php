

<div class="jumbotron">
    <h2 class="h1-responsive"><?php if(isset($_SESSION['isLogged'])): ?>
        <p>Olá, <?php echo $_SESSION['email'];?></p>
    <?php endif; ?></h2>
    <p class="lead">Com intuito de melhorar os nossos serviços e atendimento, além de oferecer serviços que façam a diferença no seu dia a dia, a Viridário elaborou uma caixa de sugestões. A sua opinião é muito importante para nós!</p>
    <hr class="my-2">
    <p>Deixe quantas sugestões quiser.</p>

<!-- Caixa de Sugestões -->
<form class="text-center border border-light p-5" method="POST" action="../projeto/sugestoes/sugestoes.php">

  <p class="h4 mb-4" id="cadastro">Caixa de Sugestões</p>
  <br>

  <!-- Sugestão -->
  <div class="form-group">
      <textarea class="form-control rounded-0" id="mensagem" name="mensagem" rows="5" placeholder="Sugestão" required></textarea>
  </div>

  <!-- Botão enviar -->
  <button class="btn btn-success btn-lg" type="submit">Enviar</button>

</form>







