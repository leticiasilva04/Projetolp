<!-- Grid -->
<h4 class="card-title h4 pb-2 green-text text-center" id="servicos"><strong>NOSSOS PRINCIPAIS SERVIÇOS</strong></h4>

<div class="container">
  <div class="row">

<div class="card-deck">


    <!-- First column -->
    <div class="col-sm">

      <!-- Card -->
  <div class="card mb-4">

    <!--Card image-->
    <div class="view overlay">
      <img class="card-img-top" src="../imagens/imagem3.jpg"
        alt="Card image cap">
      <a href="#!">
        <div class="mask rgba-white-slight"></div>
      </a>
    </div>

    <!--Card content-->
    <div class="card-body">
      <h4 class="card-title">Implantação de Jardins</h4>
      <p class="card-text"> O processo será composto pelo planejamento logístico, preparo adequado do terreno, plantio e a locação das plantas.</p>
      <button type="button" class="btn btn-light-green btn-md">Saiba mais</button>
    </div>
  </div>
      <!-- Card -->
    </div>
    <!-- First column -->


    <!-- Second column -->
    <div class="col-sm">

  <!-- Card -->
  <div class="card mb-4">

    <!--Card image-->
    <div class="view overlay">
      <img class="card-img-top" src="../imagens/imagem4.jpg"
        alt="Card image cap">
      <a href="#!">
        <div class="mask rgba-white-slight"></div>
      </a>
    </div>

    <!--Card content-->
    <div class="card-body">
      <h4 class="card-title">Manutenção de Jardins</h4>
      <p class="card-text"> Para manter a saúde das suas plantas, iremos realizar a retirada do lixo, limpeza do jardim, replantio de mudas e adubação do solo.</p>
      <button type="button" class="btn btn-light-green btn-md">Saiba mais</button>
    </div>
  </div>
      <!-- Card -->
    </div>
    <!-- Second column -->


    <!-- Three column -->
    <div class="col-sm">

  <!-- Card -->
  <div class="card mb-4">

    <!--Card image-->
    <div class="view overlay">
      <img class="card-img-top" src="../imagens/imagem5.jpg"
        alt="Card image cap">
      <a href="#!">
        <div class="mask rgba-white-slight"></div>
      </a>
    </div>

    <!--Card content-->
    <div class="card-body">
      <h4 class="card-title">Controle de Pragas</h4>
      <p class="card-text">Iremos acabar com as pragas, utilizando produtos naturais que não prejudicam o meio ambiente.</p>
      <button type="button" class="btn btn-light-green btn-md">Saiba mais</button>
    </div>
  </div>
  <!-- Card -->
    </div>
    <!-- Three column -->

  </div>
  </div>
</div>
<!-- Grid -->