<?php 

//A função uniqid() no PHP é uma função embutida que é usada para gerar um ID único baseado no tempo atual em microssegundos (micro tempo).
$filename = uniqid() . ".txt";

$myfile = fopen($filename, "a") or die("Não foi possível abrir o arquivo!");

fwrite($myfile, $_POST['nome']."\n");
fwrite($myfile, $_POST['email']."\n");
fwrite($myfile, $_POST['mensagem']."\n");
fwrite($myfile, '');


fclose($myfile);


 header("Location: ../../projeto/logado.php");
 exit;


?>