<?php 

$filename = "contas" . ".txt";

$myfile = fopen($filename, "a") or die("Não foi possível abrir o arquivo!");

$data = array(
  "email" => $_POST['email'],
  "senha" => $_POST['senha']
);

$json_data = json_encode($data);
fwrite($myfile, $json_data."\n");
fclose($myfile);
$conta_criada_com_sucesso = true;
    

if ($conta_criada_com_sucesso) {

  // Redireciona o usuário para a página home
  header("Location: ../index.php");
  exit;
} else {
  // Caso contrário, exibe uma mensagem de erro
  echo "Ocorreu um erro ao criar a conta.";
}









?>

  <!-- jQuery -->
  <script type="text/javascript" src="../assets/js/jquery.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="../assets/js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="../assets/js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="../assets/js/mdb.min.js"></script>
  <!-- Your custom scripts (optional) -->
  <link rel="stylesheet" href="../assets/css/about.css">
</body>
</html>

