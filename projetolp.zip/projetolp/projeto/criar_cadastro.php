<?php include '../include/cabecalho.php'; ?>

<title>Empresa Viridário</title>
  <!-- MDB icon -->
  <link rel="icon" href="https://cdn-icons-png.flaticon.com/512/4147/4147953.png" type="image/x-icon">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
  <!-- Google Fonts Roboto -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
  <!-- Bootstrap core CSS -->
  <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
  <!-- Material Design Bootstrap -->
  <link rel="stylesheet" href="../assets/css/mdb.min.css">
  <!-- Your custom styles (optional) -->
  <link rel="stylesheet" href="../assets/css/style.css">

</head>
<body>
    <header>

<?php include '../include/navbar_sec.php'; ?>

</header>
    <main>
            <?php include '../include/cadastro.php'; ?>
        </div>
    </main>

    <?php include '../include/rodape.php'; ?>

<!-- End your project here-->

  <!-- jQuery -->
  <script type="text/javascript" src="../assets/js/jquery.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="../assets/js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="../assets/js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="../assets/js/mdb.min.js"></script>
  <!-- Your custom scripts (optional) -->
  <link rel="stylesheet" href="../assets/css/about.css">
</body>
</html>