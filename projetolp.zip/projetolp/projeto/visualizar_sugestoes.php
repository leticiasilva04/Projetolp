
<title>Empresa Viridário</title>
<!-- MDB icon -->
<link rel="icon" href="https://cdn-icons-png.flaticon.com/512/4147/4147953.png" type="image/x-icon">
<!-- Font Awesome -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
<!-- Google Fonts Roboto -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="../assets/css/bootstrap.min.css">
<!-- Material Design Bootstrap -->
<link rel="stylesheet" href="../assets/css/mdb.min.css">
<!-- Your custom styles (optional) -->
<link rel="stylesheet" href="../assets/css/style.css">

</head>
<body>
  <header>

<?php include '../include/navbar_sec.php'; ?>

</header>
  <main>
  <?php

$dir = './sugestoes/';
$arquivos = glob($dir . '*.txt');
$contador = 1;

// Loop para ler o conteúdo de cada arquivo e exibir na página
foreach($arquivos as $arquivo){
    $sugestao = file_get_contents($arquivo);
    echo '<div class="media d-block d-md-flex mt-4">';
    echo '<img class="d-flex mb-3 mx-auto media-image z-depth-1" src="../imagens/imagem7.jpg" style="width: 150px; height: 150px;" alt="imagem">';
    echo '<div class="media-body text-center text-md-left ml-md-3 ml-0 text-center">';
    echo '<h3 class="mt-0 font-weight-bold">Sugestão ' . $contador . ' </h3>';
    echo '<p font-size: 18px;>' . $sugestao . '</p>';
    echo '</div></div>';
    $contador++;
}
  
?>
     
</div>
</main>

<?php include '../include/rodape.php'; ?>

<!-- End your project here-->

<!-- jQuery -->
<script type="text/javascript" src="../assets/js/jquery.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="../assets/js/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="../assets/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="../assets/js/mdb.min.js"></script>
<!-- Your custom scripts (optional) -->
<link rel="stylesheet" href="../assets/css/about.css">
</body>
</html>




