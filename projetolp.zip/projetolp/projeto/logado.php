<title>Empresa Viridário</title>
  <!-- MDB icon -->
  <link rel="icon" href="https://cdn-icons-png.flaticon.com/512/4147/4147953.png" type="image/x-icon">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
  <!-- Google Fonts Roboto -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
  <!-- Bootstrap core CSS -->
  <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
  <!-- Material Design Bootstrap -->
  <link rel="stylesheet" href="../assets/css/mdb.min.css">
  <!-- Your custom styles (optional) -->
  <link rel="stylesheet" href="../assets/css/style.css">

<?php include '../include/cabecalho.php'; ?>
<?php include '../mylib/login_function.php'; ?>

</head>
<body>
    <header>

<?php include '../include/navbar_sec.php'; ?>

</header>
    <main>
    
    <?php    
    session_start();

    if(isset($_POST['email']) && isset($_POST['senha'])){
     $email = $_POST['email'];
     $senha = $_POST['senha'];
     login($email, $senha);
    }

include '../include/caixa_sugestoes.php'; ?>
          
        </div>


   <!-- Deslogar -->
    <form class="text-center border border-light p-5" action="../mylib/deslogar.php">
    <blockquote class="blockquote bq-success">
      <p class="bq-title">Deseja deslogar da conta?</p>
      <button class="btn btn-success btn-block my-4" name="logout" type="submit">Sair</button>
    </blockquote>
    </form>
<!-- Deslogar -->
   
    <!-- Mural de Sugestões -->
    <form class="text-center border border-light p-5" action="visualizar_sugestoes.php">
        <blockquote class="blockquote bq-success">
         <button class="btn aqua-gradient" type="submit">Mural de Sugestões: Veja as outras sugestões!</button>
        </blockquote>
    </form>
    <!-- Mural de Sugestões -->

    </main>

    <?php include '../include/rodape.php'; ?>

<!-- End your project here-->
  <!-- jQuery -->
  <script type="text/javascript" src="../assets/js/jquery.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="../assets/js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="../assets/js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="../assets/js/mdb.min.js"></script>
  <!-- Your custom scripts (optional) -->
  <link rel="stylesheet" href="../assets/css/about.css">
</body>
</html>